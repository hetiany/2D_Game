#include "playersprite.h"
#include "gamedata.h"
#include "frameFactory.h"

void PlayerSprite::advanceFrame(Uint32 ticks) {
	timeSinceLastFrame += ticks;
  if (timeSinceLastFrame > frameInterval) {
    if (flag == true && !gameover){
        currentFrame = (currentFrame+1) % (numberOfFrames / 3);
    }else if (flag == false && !gameover) {
        currentFrame = (currentFrame+3) % (numberOfFrames / 3);
    }else if (gameover){
        currentFrame = (currentFrame+5) % (numberOfFrames / 3);
      if (currentFrame == 1)  {
        ex_count += 1;
      }
    }

    timeSinceLastFrame = 0;
  }
}


PlayerSprite::PlayerSprite( const std::string& name) :
  Drawable(name, 
           Vector2f(Gamedata::getInstance().getXmlInt(name+"/startLoc/x"), 
                    Gamedata::getInstance().getXmlInt(name+"/startLoc/y")), 
           Vector2f(Gamedata::getInstance().getXmlInt(name+"/speedX"),
                    Gamedata::getInstance().getXmlInt(name+"/speedY"))
           ),
  frames( FrameFactory::getInstance().getFrames(name) ),
  worldWidth(Gamedata::getInstance().getXmlInt("world/width")),
  worldHeight(Gamedata::getInstance().getXmlInt("world/height")),
  
  velX(Gamedata::getInstance().getXmlInt(name+"/speedX")),
  velY(Gamedata::getInstance().getXmlInt(name+"/speedY")),

  currentFrame(0),
  numberOfFrames( Gamedata::getInstance().getXmlInt(name+"/frames") ),
  frameInterval( Gamedata::getInstance().getXmlInt(name+"/frameInterval") ),
  timeSinceLastFrame( 0 ),
  frameWidth(frames[0]->getWidth()),
  frameHeight(frames[0]->getHeight()),
  flag(false),
  collision(new PerPixelCollisionStrategy),
  bullets("bullet"),
  minBulletSpeed(Gamedata::getInstance().getXmlInt("bullet/minBulletSpeed")),
  flagrota(false),
  angle(0),
  gameover(false),
  ex_count(0)
{ }

PlayerSprite::PlayerSprite(const PlayerSprite& s) :
  Drawable(s), 
  frames(s.frames),
  worldWidth( s.worldWidth ),
  worldHeight( s.worldHeight ),
  velX(s.velX),
  velY(s.velY),
  currentFrame(s.currentFrame),
  numberOfFrames( s.numberOfFrames ),
  frameInterval( s.frameInterval ),
  timeSinceLastFrame( s.timeSinceLastFrame ),
  frameWidth( s.frameWidth ),
  frameHeight( s.frameHeight ),
  flag(false),
  collision(new PerPixelCollisionStrategy),
  bullets(s.bullets),
  minBulletSpeed(s.minBulletSpeed),
  flagrota(false),
  angle(0),
  gameover(false),
  ex_count(0)
  { }
  
 void PlayerSprite::stop(bool x, bool y){
  if(y){velocityY(0);}
  if(x){velocityX(0);}
	}
 void PlayerSprite::up(){
    if(gameover){
      velocityY(0);
    }
    else{
	     velocityY(-velY);
    }
  }
 void PlayerSprite::down(){
     if(gameover){
      velocityY(0);
    }
    else{
	  velocityY(velY);
    }
  }
 void PlayerSprite::left(){
       if(gameover){
      velocityX(0);
    }
    else{
      flag = true;
      velocityX(-velX);
      }
  }
 void PlayerSprite::right(){
    if(gameover){
      velocityX(0);
    }
    else{
      flag = false;
      velocityX(velX);
    }
  }

 void PlayerSprite::shoot() { 
    Vector2f vel = getVelocity();
    float x = X();
    float y = Y() + frameHeight/3;
    if(flag == true){
      std::cout<<"left"<<std::endl;
      x = X() - frameWidth;
      vel[0] -= minBulletSpeed; 
    }else{
      std::cout<<"right"<<std::endl;
      x = X() + frameWidth;
      vel[0] += minBulletSpeed; 
      
    }
    bullets.shoot(Vector2f(x, y), vel);

  }

void PlayerSprite::draw() const { 
  Uint32 x = static_cast<Uint32>(X());
  Uint32 y = static_cast<Uint32>(Y());

  if (flag == true && !gameover){
    frames[currentFrame+2]->draw(x, y, angle);
  }else if (flag == false && !gameover){
    frames[currentFrame]->draw(x, y, angle);
  }else if (gameover && ex_count<3){
    frames[currentFrame+4]->draw(x, y, angle);
  }
 bullets.draw();
}



void PlayerSprite::update(Uint32 ticks) { 

  advanceFrame(ticks);
  bullets.update(ticks);  

  Vector2f incr = getVelocity() * static_cast<float>(ticks) * 0.001;
  setPosition(getPosition() + incr);

  if(flagrota == true){
    angle += 5;
  }

  if(angle > 360){
    angle = 0;
    flagrota = false;
  }


  if ( Y() < 0) {
    Y(0);
  }
  if ( Y() > worldHeight-frameHeight) {
    Y(worldHeight-frameHeight);
  }

  if ( X() < 0) {
    X(0);
  }
  
  if ( X() > worldWidth-frameWidth) {
    X(worldWidth-frameWidth);
  }  

}
