#include <string>
#include "drawable.h"

class FallSprite : public Drawable {
public:
  FallSprite(const std::string&);
  FallSprite(const std::string&, const Vector2f& pos, const Vector2f& vel);
  FallSprite(const std::string&, 
         const Vector2f& pos, const Vector2f& vel, const Frame*);
  FallSprite(const FallSprite& s);
  virtual ~FallSprite() { } 
  FallSprite& operator=(const FallSprite&);

  virtual const Frame* getFrame() const { return frame; }
  virtual void draw() const;

  virtual void update(Uint32 ticks);
  virtual int getzoom() const { return Zoom;};

private:
  const Frame * frame;
  int frameWidth;
  int frameHeight;
  int worldWidth;
  int worldHeight;
  int getDistance(const FallSprite*) const;
  int angle;
  Vector2f Initspeed(int speedX, int speedY);
  int Zoom;
};

