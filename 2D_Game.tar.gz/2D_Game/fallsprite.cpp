#include <cmath>
#include "fallsprite.h"
#include "gamedata.h"
#include "frameFactory.h"


Vector2f FallSprite::Initspeed(int speedX, int speedY)
{
     float x= Gamedata::getInstance().getRandInRange(70, speedX+70);
     x= (rand()%2? -x:x);
     float y= Gamedata::getInstance().getRandInRange(70, speedY+70);
     y= (rand()%2? -y:y);
     return Vector2f(x,y);
}

FallSprite::FallSprite(const std::string& name) :
  Drawable(name,
           Initspeed(Gamedata::getInstance().getXmlInt("world/width"), 
                    Gamedata::getInstance().getXmlInt(name+"/startLoc/y")), 
           Initspeed(Gamedata::getInstance().getXmlInt(name+"/speed/speedX"), 
                    Gamedata::getInstance().getXmlInt(name+"/speed/speedY"))                          
           ),
  frame( FrameFactory::getInstance().getFrame(name) ),
  frameWidth(frame->getWidth()),
  frameHeight(frame->getHeight()),
  worldWidth(Gamedata::getInstance().getXmlInt("world/width")),
  worldHeight(Gamedata::getInstance().getXmlInt("world/height")),
  angle(0),
  Zoom(Gamedata::getInstance().getRandFloat(Gamedata::getInstance().getXmlFloat(name+"/min"), 
       Gamedata::getInstance().getXmlFloat(name+"/max")))
{ }

FallSprite::FallSprite(const string& n, const Vector2f& pos, const Vector2f& vel):
  Drawable(n, pos, vel), 
  frame( FrameFactory::getInstance().getFrame(n) ),
  frameWidth(frame->getWidth()),
  frameHeight(frame->getHeight()),
  worldWidth(Gamedata::getInstance().getXmlInt("world/width")),
  worldHeight(Gamedata::getInstance().getXmlInt("world/weight")),
  angle(0),
  Zoom(Gamedata::getInstance().getRandFloat(Gamedata::getInstance().getXmlFloat(n+"/min"), 
       Gamedata::getInstance().getXmlFloat(n+"/max")))
{ }

FallSprite::FallSprite(const string& n, const Vector2f& pos, const Vector2f& vel,
               const Frame* frm):
  Drawable(n, pos, vel), 
  frame( frm ),
  frameWidth(frame->getWidth()),
  frameHeight(frame->getHeight()),
  worldWidth(Gamedata::getInstance().getXmlInt("world/width")),
  worldHeight(Gamedata::getInstance().getXmlInt("world/height")),
  angle(0),
  Zoom(Gamedata::getInstance().getRandFloat(Gamedata::getInstance().getXmlFloat(n+"/min"), 
       Gamedata::getInstance().getXmlFloat(n+"/max")))
{ }

FallSprite::FallSprite(const FallSprite& s) :
  Drawable(s), 
  frame(s.frame),
  frameWidth(s.getFrame()->getWidth()),
  frameHeight(s.getFrame()->getHeight()),
  worldWidth(Gamedata::getInstance().getXmlInt("world/width")),
  worldHeight(Gamedata::getInstance().getXmlInt("world/height")),
  angle(s.angle),
  Zoom(s.Zoom)
{ }

FallSprite& FallSprite::operator=(const FallSprite& rhs) {
  Drawable::operator=( rhs );
  frame = rhs.frame;
  frameWidth = rhs.frameWidth;
  frameHeight = rhs.frameHeight;
  worldWidth = rhs.worldWidth;
  worldHeight = rhs.worldHeight;
  Zoom = rhs.Zoom;
  return *this;
}

void FallSprite::draw() const { 
  Uint32 x = static_cast<Uint32>(X());
  Uint32 y = static_cast<Uint32>(Y());
  frame->draw(x, y, Zoom, Zoom,1); 
}

int FallSprite::getDistance(const FallSprite *obj) const { 
  return hypot(X()-obj->X(), Y()-obj->Y());
}

void FallSprite::update(Uint32 ticks) { 
  Vector2f incr = getVelocity() * static_cast<float>(ticks) * 0.001;
  setPosition(getPosition() + incr);

  if ( Y() < 0) {
    velocityY( abs( velocityY() ) );
  }
  if ( Y() > worldHeight-frameHeight) {
	Y(0);  
    velocityY( -abs( velocityY() ) );
  }

  if ( X() < 0) {
    velocityX( abs( velocityX() ) );
  }
  if ( X() > worldWidth-frameWidth) {
    velocityX( -abs( velocityX() ) );
  }  
}
