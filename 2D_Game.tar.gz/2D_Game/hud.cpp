#include "hud.h"
#include "clock.h"

Hud::Hud() :
  width(Gamedata::getInstance().getXmlInt("hud/width")),
  height(Gamedata::getInstance().getXmlInt("hud/height")),
  screen(IOManager::getInstance().getScreen()),
  start(Gamedata::getInstance().getXmlInt("hud/X"),
        Gamedata::getInstance().getXmlInt("hud/Y")
  ), 
  title( Gamedata::getInstance().getXmlStr("screenTitle") ),
  io( IOManager::getInstance() ),
  //clock( Clock::getInstance() ),
  //viewport( Viewport::getInstance() ),
  RED( SDL_MapRGB(screen->format, 0xff, 0x00, 0x00) )
  {}

void Hud::draw() const {
  Draw_AALine(screen, start[0], start[1]+height/2, 
                      start[0]+width, start[1]+height/2, 
                      height, 0xff, 0xff, 0xff, 0xff/2);
  Draw_AALine(screen, start[0], start[1], 
                      start[0]+width, start[1], 1.0f, RED);
  Draw_AALine(screen, start[0], start[1]+height, 
                      start[0]+width, start[1]+height, 1.0f, RED);
  Draw_AALine(screen, start[0], start[1], 
                      start[0], start[1]+height, 2.0f, RED);
  Draw_AALine(screen, start[0]+width, start[1], 
                      start[0]+width, start[1]+height, 2.0f, RED);
                      
  //io.printMessageValueAt("Seconds: ", Clock::getInstance().getSeconds(), start[0]+10, start[1]+30);
  //io.printMessageValueAt("fps: ", Clock::getInstance().getAvgFps(), start[0]+10, start[0]+50);
  //io.printMessageAt("Press UP/DOWN/LEFT/RIGHT to control player", start[0]+10, start[0]+70);
  //io.printMessageAt("F1 toggles this Hud", start[0]+10, start[0]+90);
  //io.printMessageAt(title, start[0]+10, start[0]+110);
 }
 
