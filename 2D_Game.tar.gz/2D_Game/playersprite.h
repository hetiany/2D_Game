#ifndef PLAYERSPRITE__H
#define PLAYERSPRITE__H
#include <string>
#include <vector>
#include "drawable.h"
#include "collisionStrategy.h"
#include "bullets.h"

class PlayerSprite : public Drawable {
public:
  PlayerSprite(const std::string&);
  PlayerSprite(const PlayerSprite&);
  virtual ~PlayerSprite() { delete collision;} 

  virtual void draw() const;
  virtual void update(Uint32 ticks);
  virtual const Frame* getFrame() const { 
    return frames[currentFrame]; 
  }
  virtual void stop(bool, bool);
  virtual void up();
  virtual void down();
  virtual void left();
  virtual void right();
  virtual void setangleflag(){
    flagrota = true;
  }
  virtual bool collidedWith(const Drawable* d) const{
     return collision-> execute(*this, *d);
  }

  unsigned int bulletCount() const { return bullets.bulletCount(); }
  unsigned int freeCount() const { return bullets.freeCount(); }
  void shoot();


  std::list<Bullet>::iterator getBulletsBegin(){
    return bullets.getBulletsBegin();
  }
  std::list<Bullet>::iterator getBulletsEnd(){
    return bullets.getBulletsEnd();
  }
  std::list<Bullet> getBulletList(){return bullets.getBulletList();}
  void setgameover(){ gameover = true;}
  bool getgameover(){ return gameover;}
  
protected:
  const std::vector<Frame *> frames;
  int worldWidth;
  int worldHeight;
  int velX;
  int velY;

  unsigned currentFrame;
  unsigned numberOfFrames;
  unsigned frameInterval;
  float timeSinceLastFrame;
  int frameWidth;
  int frameHeight;
  bool flag;

  void advanceFrame(Uint32 ticks);
  void advanceFrameover(Uint32 ticks);
  //bool keyPressedX;
  //bool keyPressedY;
  //const float slowdown;
   virtual int getzoom() const { return 0;}
  CollisionStrategy* collision;

  Bullets bullets;
  int minBulletSpeed;
  bool flagrota;
  int angle;
  bool gameover;
  PlayerSprite& operator=(const PlayerSprite&);
  int ex_count;
};

#endif
