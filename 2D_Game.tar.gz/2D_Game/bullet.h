#ifndef BULLET__H
#define BULLET__H
#include <string>
#include <vector>
#include "sprite.h"
#include "collisionStrategy.h"

class Bullet : public Sprite {
public:
  Bullet(const std::string&, const Vector2f&, const Vector2f&);
  Bullet(const Bullet&);
  virtual ~Bullet() {delete collision;} 
  virtual void update(Uint32 ticks);
  bool goneTooFar() const { return toofar; }
  void reset ();
  virtual bool collidedWith(const Drawable* d) const {
     return collision-> execute(*this, *d);
  }  
  void collide() {toofar = true;}
  
private:
  int distance;
  bool toofar;
  int maxdistance;
  CollisionStrategy* collision;
  Bullet& operator=(const Bullet&);
};
#endif
