#include "bullet.h"
#include "gamedata.h"
#include "frameFactory.h"
#include <cmath>


Bullet::Bullet( const std::string& name, const Vector2f& pos, const Vector2f& vel) :
  Sprite(name, pos, vel),
  distance(0),
  toofar(false),
  maxdistance(Gamedata::getInstance().getXmlInt(name+"/maxdistance")),
  collision(new PerPixelCollisionStrategy)
{ }

Bullet::Bullet(const Bullet& s) : 
  Sprite(s),
  distance(s.distance),
  toofar(s.toofar),
  maxdistance(s.maxdistance),
  //collision(s.collision)
  collision(new PerPixelCollisionStrategy)
{ }

void Bullet::reset() {
  toofar = false;
  distance = 0;
} 


void Bullet::update(Uint32 ticks) { 
  Vector2f pos = getPosition();
  Vector2f incr = getVelocity() * static_cast<float>(ticks) * 0.001;
  setPosition(pos + incr);
  if(Y() + frameHeight < 0 || Y() > worldHeight)
    toofar = true;

  if(X() < 0 || X() > worldWidth)
    toofar = true;

  distance += (hypot(X()-pos[0], Y()-pos[1]));
  if(distance > maxdistance)
    toofar = true;

}
