#include <vector>
#include <SDL.h>
#include "ioManager.h"
#include "clock.h"
#include "world.h"
#include "viewport.h"
#include <list>
#include "hud.h"
#include "playersprite.h"
#include "health.h"
#include "sound.h"
#include "smartSprite.h"

class Manager {
public:
  Manager ();
  void pause() { clock.pause(); }
  void unpause() { clock.unpause(); }
  void setNumberOfSprites(int);
  ~Manager ();
  bool play();

private:
  const bool env;
  const IOManager& io;
  Clock& clock;

  SDL_Surface * const screen;
  
  World back;
  World front;
  Viewport& viewport;

  std::vector<Drawable*> fallstone;

  std::vector<Sprite*> explode;
  std::vector<Sprite*> theOrb;
  std::vector<Sprite*> smartsprite;
 
  
  PlayerSprite* player; 

  Hud hud;
  bool showhud;

  int currentSprite;

  bool makeVideo;
  int frameCount;
  const std::string username;
  const std::string title;
  const int frameMax;
  
  bool disappear;
  //int zoom;
  void draw() const;
  void update();

  Manager(const Manager&);
  Manager& operator=(const Manager&);
  void makeFrame();
  Health playerhealth;
  SDLSound sound;
  bool checkForCollisions();
  unsigned interval;
  int lasttick;
  bool overword;
  int explodenumber;
  bool winner;
  bool stopplayer;
  Uint32 ticks1;

};
