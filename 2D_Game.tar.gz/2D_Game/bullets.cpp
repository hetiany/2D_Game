#include <cmath>
#include <iostream>
#include "bullets.h"
#include "gamedata.h"
#include "frameFactory.h"

Bullets::Bullets(const std::string& n) :
  name(n),
  myVel(Gamedata::getInstance().getXmlInt(name+"/speedX"),
        Gamedata::getInstance().getXmlInt(name+"/speedY")),
  bulletList(),
  freeList()
  {}

Bullets::Bullets(const Bullets& b) :
  name(b.name),
  myVel(b.myVel),
  bulletList(b.bulletList),
  freeList(b.freeList)
  {}


Bullets::~Bullets() {}



void Bullets::shoot(const Vector2f& position, const Vector2f& velocity) {
  if(freeList.empty()){
    Bullet b(name, position, velocity);
    bulletList.push_back(b);
  }else{
    Bullet b = freeList.front();
    freeList.pop_front();
    b.reset();
    b.setVelocity(velocity);
    b.setPosition(position);
    bulletList.push_back(b);
  }
  
}

void Bullets::draw() const { 
   std::list<Bullet>::const_iterator ptr = bulletList.begin();
   while(ptr != bulletList.end()){
    ptr->draw(); 
    ptr++;
  }
}


void Bullets::update(Uint32 ticks) { 
  std::list<Bullet>::iterator ptr = bulletList.begin();
  while(ptr != bulletList.end()){
    ptr->update(ticks);
    if(ptr->goneTooFar()){
      freeList.push_back(*ptr); 
      ptr = bulletList.erase(ptr);
    }
    else ++ptr;
  }
}



