#include "vector2f.h"
#include "ioManager.h"
#include "aaline.h"

class Health {
public:
  Health();
  Health(int x, int y, int length, int increment);
  Health(int sx, int sy, int tl, int cl, 
         float t, int inc, Uint32 c);
  void draw() const;
  void decrease();
  int currentHealth() { return currentLength; }
  void reset() { currentLength = totalLength; }
private:
  SDL_Surface* screen;
  Vector2f start;
  int totalLength;
  int currentLength;
  int thick;
  int increments;
  const Uint32 RED;
  const Uint32 GRAY;
  const Uint32 BLACK;
  const Uint32 color;
  void drawBox() const;
  Health(const Health&);
  Health& operator=(const Health&);
};
