// Hetian Yang        Game Construction
#include "manager.h"
#include "menuManager.h"
bool restart = false;

int main(int, char*[]) {
   try {
      MenuManager menuManager;
      restart = menuManager.play();
      while(restart == true){
        MenuManager menuManager;
        restart = menuManager.play();
        std:: cout << restart <<std::endl;  
       } 
   }
   catch (const string& msg) { std::cout << msg << std::endl; }
   catch (...) {
      std::cout << "Oops, someone threw an exception!" << std::endl;
   }
   return 0;
}
