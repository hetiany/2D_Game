#include <iostream>
#include <string>
#include <iomanip>
#include "multisprite.h"
#include "sprite.h"
#include "gamedata.h"
#include "manager.h"
#include "twowaymultisprite.h"
#include "fallsprite.h"
#include <algorithm>
#include "explodingSprite.h"
//#include "sound.h"


class starLess{
public:
  bool operator()(const Drawable* lhs, const Drawable* rhs){
    return lhs->getzoom() < rhs->getzoom();
    } 
};

Manager::~Manager() { 
  // These deletions eliminate "definitely lost" and
  // "still reachable"s in Valgrind.
  /*for (unsigned i = 0; i < sprites.size(); ++i) {
    delete sprites[i];
  }*/
  
  for (unsigned i = 0; i < fallstone.size(); ++i) {
    delete fallstone[i];
  }

  /*for (unsigned int i = 0; i < theOrb.size(); ++i){
    delete theOrb[i];
  }*/
  
  for (unsigned int i = 0; i < smartsprite.size(); ++i){
    delete smartsprite[i];
  }

  for (unsigned int i = 0; i < explode.size(); ++i){
    delete explode[i];
  }

  delete player;
  //delete temp;
}
 
Manager::Manager() :
  env( SDL_putenv(const_cast<char*>("SDL_VIDEO_CENTERED=center")) ),
  io( IOManager::getInstance() ),
  clock( Clock::getInstance() ),
  screen( io.getScreen() ),
  back("back", Gamedata::getInstance().getXmlInt("back/factor") ),
  front("front", Gamedata::getInstance().getXmlInt("front/factor") ),
  viewport( Viewport::getInstance() ),
  fallstone(),
  explode(),
  theOrb(),
  smartsprite(),
  //temp(new Sprite("explode")),
  player(new PlayerSprite("spaceship")),
  hud(),
  showhud(true),
  currentSprite(0),
  makeVideo( false ),
  frameCount( 0 ),
  username(  Gamedata::getInstance().getXmlStr("username") ),
  title( Gamedata::getInstance().getXmlStr("screenTitle") ),
  frameMax( Gamedata::getInstance().getXmlInt("frameMax") ),
  disappear(true),
  playerhealth(),
  sound(),
  interval(500),
  lasttick(0),
  overword(false),
  explodenumber(Gamedata::getInstance().getXmlInt("explode/Number")),
  winner(false),
  stopplayer(false),
  ticks1()
{
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
    throw string("Unable to initialize SDL: ");
  }
  SDL_WM_SetCaption(title.c_str(), NULL);
  atexit(SDL_Quit);

  for ( int i = 0; i < Gamedata::getInstance().getXmlInt("fallstone/number"); ++i)
  {
    fallstone.push_back( new FallSprite("fallstone") );
  }
  
  explode.reserve(Gamedata::getInstance().getXmlInt("explode/Number"));
  smartsprite.reserve(Gamedata::getInstance().getXmlInt("explode/Number"));
  theOrb.reserve(Gamedata::getInstance().getXmlInt("explode/Number"));
  
  for ( int i = 0; i < Gamedata::getInstance().getXmlInt("explode/Number"); ++i)
  {
    explode.push_back( new Sprite("explode") );    
    smartsprite.push_back( new SmartSprite(explode[i]->getName(), explode[i]->getPosition(), *player));
    theOrb.push_back(smartsprite[i]);
  }
  

  std::sort(fallstone.begin(), fallstone.end(), starLess());
  viewport.setObjectToTrack(player);
}


void Manager::setNumberOfSprites(int number) {
  if ( number > static_cast<int>( fallstone.size() ) ) {
    number = number - fallstone.size();
    for (int i = 0; i < number; ++i) {
      fallstone.push_back(new FallSprite("fallstone"));
    }
    //explodenumber = theOrb.size();
  }
  else {
    number = fallstone.size() - number;
    for (int i = 0; i < number; ++i) {
      delete fallstone.back();
      fallstone.pop_back();
    }
    //explodenumber = fallstone.size();
  }
}



void Manager::draw() const {
  back.draw();
  front.draw();  
  player->draw();
  playerhealth.draw();
  io.printMessageAt(title, 20, 450); 
  
  
  for(unsigned int i = 0; i < fallstone.size(); ++i){
    fallstone[i]->draw();
  }

  if(showhud){
    hud.draw();
    io.printMessageValueAt("Seconds: ", Clock::getInstance().getSeconds(), 20, 20);
    io.printMessageValueAt("fps: ", Clock::getInstance().getAvgFps(), 20, 40);
    io.printMessageAt("Press UP/DOWN/LEFT/RIGHT to control player", 20, 60);
    io.printMessageAt("F1 toggles this Hud", 20, 80);
    io.printMessageAt("Press R to rotate player", 20, 100);
    io.printMessageAt("Press B to restart game", 20, 120);
    io.printMessageAt("Press SPACE to shoot!", 20, 140);
    io.printMessageValueAt("BulletsList: ", player->bulletCount(), 20, 160 );
    io.printMessageValueAt("FreeList: ", player->freeCount(), 20, 180 ); 
    io.printMessageValueAt("Spaceship Number: ", explodenumber, 20, 200 );
    io.printMessageValueAt("fallstone Number:",fallstone.size(), 20, 220);    
  }
  
  if(overword){
    io.printgameoverCenteredAt("GAME OVER", 200); 
    io.printMessageAt("Press Esc and select Start Game to Restart Game!", 200, 100);  
    }
  
  if(winner){
    io.printgameoverCenteredAt("WINNER", 200);
    io.printMessageAt("Press Esc and select Start Game to Restart Game!", 200, 100);    
    }  


  for (unsigned int i = 0; i < theOrb.size(); ++i)
  {
  theOrb[i]->draw();
  }
  //viewport.draw();

  SDL_Flip(screen);
}

void Manager::makeFrame() {
  std::stringstream strm;
  strm << "frames/" << username<< '.' 
       << std::setfill('0') << std::setw(4) 
       << frameCount++ << ".bmp";
  std::string filename( strm.str() );
  std::cout << "Making frame: " << filename << std::endl;
  SDL_SaveBMP(screen, filename.c_str());
}

/***checkcollision***/
bool Manager::checkForCollisions()  {
  for(unsigned int i = 0; i< fallstone.size(); i++){
    if ( player->collidedWith(fallstone[i]) && clock.getTicks()-lasttick > interval ){ 
      sound[2];
      std::cout << "collidedWith" << std::endl;
      playerhealth.decrease();
      lasttick = clock.getTicks();}
      if(playerhealth.currentHealth() <= 0){
        player->setgameover();   
        return true;}
  }
  return false;
}


void Manager::update() {
  ++clock;
  Uint32 ticks = clock.getElapsedTicks();
  ticks1 = ticks1 + clock.getElapsedTicks();
  
  if(clock.getTicks() >= 3000 && disappear == true){showhud = false;}

  
  player->update(ticks);
  
  
  if ( checkForCollisions() ) {
    overword = true;    
  }

  for(unsigned int i = 0; i < fallstone.size(); ++i){
    fallstone[i]->update(ticks);
  }

   for (unsigned int i = 0; i < theOrb.size(); ++i)
  {
  theOrb[i]->update(ticks);
  } 
  
  if ( makeVideo && frameCount < frameMax ) {
    makeFrame();
  }
  back.update();
  front.update();
  viewport.update(); // always update viewport last
}

bool Manager::play() {
  SDL_Event event;
  //SDLSound sound;
  //bool orbExploded = false;
  bool done = false;
  bool keyCatch = false;
  while ( not done ) {

        /*for (unsigned int i = 0; i < theOrb.size(); ++i){
          if ( dynamic_cast<ExplodingSprite*>(theOrb[i]) ) {
            if( dynamic_cast<ExplodingSprite*>(theOrb[i])->chunkCount() == 0 ){
              delete theOrb[i];
              //dynamic_cast<Sprite*>(theOrb[i]);
              theOrb[i] = temp;
              //orbExploded = false;
             }
           }       
        }
         
       for(unsigned int i = 0; i< theOrb.size(); i++){
            for(std::list<Bullet>::iterator iter = player->getBulletsBegin();iter != player->getBulletsEnd(); ++iter){
              if ( iter->collidedWith(theOrb[i]) ){
                  if ( !(dynamic_cast<ExplodingSprite*>(theOrb[i])) ) 
                  {
                    //orbExploded = true;
                    temp = theOrb[i];
                    theOrb[i] = new ExplodingSprite(*theOrb[i]);               
                  }
              }
            }
        }*/
    

    for(unsigned int i = 0; i< theOrb.size(); i++){
        for(std::list<Bullet>::iterator iter = player->getBulletsBegin();iter != player->getBulletsEnd(); ++iter){
          if ( iter->collidedWith(theOrb[i]) ){               
              if ( !(dynamic_cast<ExplodingSprite*>(theOrb[i])) ) {
                theOrb[i] = new ExplodingSprite(*theOrb[i]);
                iter->collide();  
                --explodenumber;          
              }
          }
        }
    }

    if(explodenumber == 0){
      winner = true;
      showhud = false;
      std::vector<Drawable*>::iterator iter = fallstone.begin();
      while(iter != fallstone.end())
       iter = fallstone.erase(iter);              
    }
    

    SDL_PollEvent(&event);
    Uint8 *keystate = SDL_GetKeyState(NULL);
    if (event.type ==  SDL_QUIT) { done = true; break; }
    if(event.type == SDL_KEYUP) { 
      keyCatch = false; 
       if (event.key.keysym.sym == SDLK_LEFT) {
        player->stop(true, false);
      }
      if (event.key.keysym.sym == SDLK_RIGHT) {
        player->stop(true, false);
      }
      if (event.key.keysym.sym == SDLK_UP) {
        player->stop(false, true);
      }
      if (event.key.keysym.sym == SDLK_DOWN) {
        player->stop(false, true);
      }
    }
    if(event.type == SDL_KEYDOWN) {
      if (keystate[SDLK_ESCAPE] || keystate[SDLK_q]) {
        done = true;
        break;
      }

      if (keystate[SDLK_r] && !keyCatch) {
        keyCatch = true;
        player->setangleflag();
      }
      
       if (keystate[SDLK_b] && !keyCatch ) {
           keyCatch = true;   
           //return true;                   
        }

      if (keystate[SDLK_s] && !keyCatch) {
        keyCatch = true;
        clock.toggleSloMo();
      }
        if (keystate[SDLK_p] && !keyCatch) {
          keyCatch = true;
          if ( clock.isPaused() ) clock.unpause();
          else clock.pause();
        }

        if (keystate[SDLK_F1] && !keyCatch) {
          keyCatch = true;
          disappear = false;
          if(showhud) showhud = false;
          else showhud = true;
        }
    
        if (keystate[SDLK_F4] && !makeVideo) {
          std::cout << "Making video frames" << std::endl;
          makeVideo = true;
        }

        if (keystate[SDLK_UP]) {
          player->up();              
        }
        if (keystate[SDLK_DOWN]) {
           player->down();               
        }
        if (keystate[SDLK_LEFT]) {
           player->left();               
        }
        if (keystate[SDLK_RIGHT]) {
           player->right();               
        }
        if (keystate[SDLK_SPACE] && !keyCatch ) {
            keyCatch = true;
            sound[3];
            player->shoot();          
        }
    }

    draw();
    update();
  }
    return false;
}
