#include "vector2f.h"
#include "ioManager.h"
#include "aaline.h"
//#include "clock.h"
#include "viewport.h"
#include "ioManager.h"
#include "vector2f.h"


class Hud {
public:
  Hud();
  void draw() const;
  void update(Uint32);
private:
  float width;
  float height;
  SDL_Surface* screen;
  Vector2f start;
  std::string title;
  const IOManager& io;
  //Clock& clock;
  //Viewport& viewport;
  const Uint32 RED;
  Hud(const Hud&);
  Hud& operator=(const Hud&);
};
