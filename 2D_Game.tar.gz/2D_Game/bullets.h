#ifndef BULLETS__H
#define BULLETS__H

#include <SDL.h>
#include <iostream>
#include <list>
#include "bullet.h"


class Bullets {
public:
  Bullets (const std::string&);
  Bullets (const Bullets&);

  ~Bullets ();

  void shoot(const Vector2f& position, const Vector2f& velocity);
  void draw() const;
  void update(Uint32 ticks);
  unsigned int bulletCount() const { return bulletList.size(); }
  unsigned int freeCount() const { return freeList.size(); }

  std::list<Bullet>::iterator getBulletsBegin(){
    std::list<Bullet>::iterator iter = bulletList.begin();
    return iter;
  }
  std::list<Bullet>::iterator getBulletsEnd(){
    std::list<Bullet>::iterator iter = bulletList.end();
    return iter;
  }
  
  std::list<Bullet> getBulletList(){return bulletList;}

private:
  std::string name;
  Vector2f myVel;
  std::list<Bullet> bulletList;
  std::list<Bullet> freeList;
};

#endif
